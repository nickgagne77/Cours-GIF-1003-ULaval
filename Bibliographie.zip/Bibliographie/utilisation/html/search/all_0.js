var searchData=
[
  ['creerjournal_0',['creerJournal',['../gestion_bibliographie_8cpp.html#a67bf1fbd6a0dd340b5250a3cfab216ce',1,'gestionBibliographie.cpp']]],
  ['creerouvrage_1',['creerOuvrage',['../gestion_bibliographie_8cpp.html#af18369f1512ea713765ecb9550e6f444',1,'gestionBibliographie.cpp']]]
];
