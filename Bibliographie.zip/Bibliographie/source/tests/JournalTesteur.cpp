/**
 * \file JournalTesteur.cpp
 * \brief Test unitaire de la classe Journal.
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 * A tester:
 *     Journal (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
             const std::string& p_identifiant, const std::string& p_nom,
             int p_volume, int p_numero, int p_page);
       const std::string& reqNom () const;
       int reqVolume () const;
       int reqNumero () const;
       int reqPage () const;
       virtual const std::string reqReferenceFormate () const;
       virtual Reference* clone () const;
 */
#include <gtest/gtest.h>
#include <iostream>
#include <sstream>
#include "Journal.h"
#include "ContratException.h"
#include "validationFormat.h"

using namespace std;
using namespace util;
using namespace biblio;


/**
 * \brief Test du constructeur avec paramètres Journal (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
             const std::string& p_identifiant, const std::string& p_nom,
             int p_volume, int p_numero, int p_page),
 *     Cas valide: ConstructeurValide Tous les paramètres sont valides.
 *     Cas invalides: ConstructeurAuteursInvalide : L'auteur est invalide.
 *                    ConstructeurTitreVide Le titre est vide.
 *                    ConstructeurAnneeInvalide L'année est inférieure à 0.
 *                    ConstructeurIdentifiantInvalide L'identifiant est invalide.
 *                    ConstructeurNomVide Le nom du Journal est vide.
 *                    ConstructeurVolumeInvalide Le volume est inférieur à 0.
 *                    ConstructeurNumeroInvalide Le numéro est inférieur à 0.
 *                    ConstructeurPageInvalide La page est inférieur à 0.
 */

TEST (Journal, ConstructeurValide)
{
  Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                     "The Journal of Apple", 13, 13, 113);

  ASSERT_EQ ("Steve Jobs", unJournal.reqAuteurs ());
  ASSERT_EQ ("Hello World", unJournal.reqTitre ());
  ASSERT_EQ (1984, unJournal.reqAnnee ());
  ASSERT_EQ ("ISSN 1937-4771", unJournal.reqIdentifiant ());
  ASSERT_EQ ("The Journal of Apple", unJournal.reqNom ());
  ASSERT_EQ (13, unJournal.reqVolume ());
  ASSERT_EQ (13, unJournal.reqNumero ());
  ASSERT_EQ (113, unJournal.reqPage ());

  ASSERT_TRUE (validerFormatNom (unJournal.reqAuteurs ()));
  ASSERT_TRUE (!unJournal.reqTitre ().empty ());
  ASSERT_TRUE (unJournal.reqAnnee () > 0);
  ASSERT_TRUE (validerCodeIssn (unJournal.reqIdentifiant ()));
  ASSERT_TRUE (!unJournal.reqNom ().empty ());
  ASSERT_TRUE (unJournal.reqVolume () > 0);
  ASSERT_TRUE (unJournal.reqNumero () > 0);
  ASSERT_TRUE (unJournal.reqPage () > 0);
}


TEST (Journal, ConstructeurAuteursInvalide)
{
  ASSERT_THROW (Journal unJournal ("_Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                                   "The Journal of Apple", 13, 13, 113),
                PreconditionException)
          << "L'auteur doit être valide.";
}


TEST (Journal, ConstructeurTitreVide)
{
  ASSERT_THROW (Journal unJournal ("Steve Jobs", "", 1984, "ISSN 1937-4771",
                                   "The Journal of Apple", 13, 13, 113),
                PreconditionException)
          << "Le titre ne doit pas être vide.";
}


TEST (Journal, ConstructeurAnneeInvalide)
{
  ASSERT_THROW (Journal unJournal ("Steve Jobs", "Hello World", -500, "ISSN 1937-4771",
                                   "The Journal of Apple", 13, 13, 113),
                PreconditionException)
          << "L'année doit être supérieure à 0.";
}


TEST (Journal, ConstructeurIdentifiantInvalide)
{
  ASSERT_THROW (Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1234-5678",
                                   "The Journal of Apple", 13, 13, 113),
                PreconditionException)
          << "L'identifiant doit être valide.";
}


TEST (Journal, ConstructeurNomVide)
{
  ASSERT_THROW (Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                                   "", 13, 13, 113),
                PreconditionException)
          << "Le nom du journal ne doit pas être vide.";
}


TEST (Jounral, ConstructeurVolumeInvalide)
{
  ASSERT_THROW (Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                                   "The Journal of Apple", -13, 13, 113),
                PreconditionException)
          << "Le volume ne doit pas être inférieur à 0";
}


TEST (Journal, ConstructeurNumeroInvalide)
{
  ASSERT_THROW (Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                                   "The Journal of Apple", 13, -1, 113),
                PreconditionException)
          << "Le numéro ne doit pas être inférieur à 0";
}


TEST (Journal, ConstructeurPageInvalide)
{
  ASSERT_THROW (Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                                   "The Journal of Apple", 13, 13, -42),
                PreconditionException)
          << "La page ne doit pas être inférieur à 0";
}

/**
 * \class JournalValide
 * \brief Création d'une fixture utilisé pour les tests de la classe Journal
 */
class JournalValide : public ::testing::Test
{

public:


  JournalValide () :
  f_journal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
             "The Journal of Apple", 13, 13, 113) { };
  Journal f_journal;
} ;


/**
 * \brief Test de la méthode const std::string& reqNom () const.
 *     Cas valide: reqNom: Vérifie le retour du nom du journal.
 *     Cas invalide: aucun à tester.
 */

TEST_F (JournalValide, reqNom)
{
  ASSERT_EQ (f_journal.reqNom (), "The Journal of Apple");
}


/**
 * \brief Test de la méthode int reqVolume () const.
 *     Cas valide: reqVolume: Vérifie le retour du volume.
 *     Cas invalide: aucun à tester.
 */

TEST_F (JournalValide, reqVolume)
{
  ASSERT_EQ (f_journal.reqVolume (), 13);
}


/**
 * \brief Test de la méthode int reqNumero () const.
 *     Cas valide: reqNumero: Vérifie le retour du numéro.
 *     Cas invalide: aucun à tester.
 */

TEST_F (JournalValide, reqNumero)
{
  ASSERT_EQ (f_journal.reqNumero (), 13);
}


/**
 * \brief Test de la méthode int reqPage () const.
 *     Cas valide: reqPage: Vérifie le retour de la page.
 *     Cas invalide: aucun à tester.
 */

TEST_F (JournalValide, reqPage)
{
  ASSERT_EQ (f_journal.reqPage (), 113);
}


/**
 * \brief Test de la méthode virtual std::string reqReferenceFormate () const.
 *     Cas valide: reqReferenceFormate : Vérifie le retour du formatage d'un ouvrage.
 *     Cas invalide: aucun à tester.
 */
TEST_F (JournalValide, reqReferenceFormate)
{
  ostringstream os;
  os << "Steve Jobs. Hello World. The Journal of Apple, vol. 13, "
          << "no. 13, pp. 113, 1984. ISSN 1937-4771.";

  ASSERT_EQ (os.str (), f_journal.reqReferenceFormate ());
}


/**
 * \brief Test de la méthode virtual Reference* clone () const;.
 *     Cas valide: cloneValide: Vérifie l'objet *unClone est identique à f_journal
 *     Cas invalide: aucun.
 */
TEST_F (JournalValide, cloneValide)
{
  Reference* unClone = f_journal.clone ();

  ASSERT_EQ (f_journal.reqAuteurs (), unClone->reqAuteurs ());
  ASSERT_EQ (f_journal.reqTitre (), unClone->reqTitre ());
  ASSERT_EQ (f_journal.reqAnnee (), unClone->reqAnnee ());
  ASSERT_EQ (f_journal.reqIdentifiant (), unClone->reqIdentifiant ());
  ASSERT_EQ (f_journal.reqReferenceFormate (), unClone->reqReferenceFormate ());

  delete unClone;
}


