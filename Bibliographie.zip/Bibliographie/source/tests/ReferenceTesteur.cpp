/**
 * \file ReferenceTesteur.cpp
 * \brief Test unitaire de la classe Reference.
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 * A tester:
 *      Reference (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
                   const std::string& p_identifiant);
        void asgAnnee (int p_annee)
        bool operator== (const Reference& p_reference) const
        const std::string& reqAuteurs () const
        const std::string& reqTitre () const
        int reqAnnee () const
        const std::string& reqIdentifiant () const
        virtual std::string reqReferenceFormate () const = 0
        virtual Reference* clone () const = 0 (**Testée dans les classes enfants**)
 */
#include <gtest/gtest.h>
#include "Reference.h"
#include "ContratException.h"
#include "validationFormat.h"
#include <string>

using namespace std;
using namespace util;
using namespace biblio;

/**
 * \class ReferenceTest
 * \brief Classe de test permettant de tester la classe abstraite Reference.
 */
class ReferenceTest : public Reference
{

public:


  ReferenceTest (const std::string& p_auteurs, const std::string& p_titre,
                 const unsigned int p_annee, const std::string& p_identifiant) :
  Reference (p_auteurs, p_titre, p_annee, p_identifiant) { };


  virtual std::string
  reqReferenceFormate () const
  {
    ostringstream os;
    os << reqAuteurs () << ". ";
    os << reqTitre () << ". ";
    return os.str ();
  };


  virtual Reference*
  clone () const
  {
    return nullptr; // et non return new Reference (*this);
  };
} ;


/**
 * \brief Test du constructeur Reference (const std::string& p_auteurs,
 *             const std::string& p_titre, int p_annee,
               const std::string& p_identifiant);
 *     Cas valide: ConstructeurValide Tous les paramètres sont valides.
 *     Cas invalides: ConstructeurAuteursInvalide : L'auteur est invalide.
 *                    ConstructeurTitreVide Le titre est vide.
 *                    ConstructeurAnneeInvalide L'année est inférieure à 0.
 *                    ConstructeurIdentifiantVide L'identifiant est vide.
 */
TEST (Reference, ConstructeurValide)
{
  ReferenceTest referenceTest ("Micheal Scott", "Somehow I manage",
                               2010, "ISBN 978-0-387-77591-3");

  ASSERT_EQ ("Micheal Scott", referenceTest.reqAuteurs ());
  ASSERT_EQ ("Somehow I manage", referenceTest.reqTitre ());
  ASSERT_EQ (2010, referenceTest.reqAnnee ());
  ASSERT_EQ ("ISBN 978-0-387-77591-3", referenceTest.reqIdentifiant ());

  ASSERT_TRUE (validerFormatNom (referenceTest.reqAuteurs ()));
  ASSERT_TRUE (referenceTest.reqAnnee () > 0);
  ASSERT_TRUE (!referenceTest.reqIdentifiant ().empty ());
}


TEST (Reference, ConstructeurAuteursInvalide)
{
  ASSERT_THROW (ReferenceTest referenceTest ("Mike--", "Somehow I manage",
                                             2010, "ISBN 978-0-387-77591-3"),
                PreconditionException)
          << "L'auteur doit être valide.";
}


TEST (Reference, ConstructeurTitreVide)
{
  ASSERT_THROW (ReferenceTest referenceTest ("Micheal Scott", "",
                                             2010, "ISBN 978-0-387-77591-3"),
                PreconditionException)
          << "Le titre ne doit pas être vide.";
}


TEST (Reference, ConstructeurAnneeInvalide)
{
  ASSERT_THROW (ReferenceTest referenceTest ("Micheal Scott", "Somehow I manage",
                                             0, "ISBN 978-0-387-77591-3"),
                PreconditionException)
          << "L'année doit être supérieure à 0.";
}


TEST (Reference, ConstructeurIdentifiantVide)
{
  ASSERT_THROW (ReferenceTest referenceTest ("Micheal Scott", "Somehow I manage",
                                             2010, ""), PreconditionException)
          << "Lidentifiant ne doit pas être vide.";
}

/**
 * \class ReferenceValide
 * \brief Création d'une fixture utilisé pour tester les méthodes de la classe Reference
 */
class ReferenceValide : public ::testing::Test
{

public:


  ReferenceValide () :
  f_reference ("Micheal Scott", "Somehow I manage", 2010, "ISBN 978-0-387-77591-3") { }
  ReferenceTest f_reference;
} ;


/**
 * \brief Test de la méthode void asgAnnee (int p_annee).
 *     Cas valide: asgAnneeValide : L'année fournie est supérieure à 0.
 *     Cas invalide: asgAnneeInvalide : L'année fournie n'est pas supérieure à 0.
 */
TEST_F (ReferenceValide, asgAnneeValide)
{
  f_reference.asgAnnee (2022);
  ASSERT_EQ (2022, f_reference.reqAnnee ());
  ASSERT_TRUE (f_reference.reqAnnee () > 0);
}


TEST_F (ReferenceValide, asgAnneeInvalide)
{
  ASSERT_THROW (f_reference.asgAnnee (0), PreconditionException)
          << "L'année doit être supérieure à 0.";
}


/**
 * \brief Test de la méthode bool operator== (const Reference& p_reference) const.
 *     Cas valide: operateurEgalite : Vérifie la validité de l'opérateur d'égalité.
 *     Cas invalide: operateurAuteursNE: Les references n'ont pas le même auteur.
 *                   operateurTitreNE: Les references n'ont pas le même titre.
 *                   operateurAnneeNE: Les references n'ont pas la même année.
 *                   operateurIdentifiantNE: Les references n'ont pas le même identifiant.
 */
TEST_F (ReferenceValide, operateurEgalite)
{
  ReferenceTest nouvelleReference ("Micheal Scott", "Somehow I manage",
                                   2010, "ISBN 978-0-387-77591-3");
  ASSERT_TRUE (f_reference == nouvelleReference);
}


TEST_F (ReferenceValide, operateurAuteursNE)
{
  ReferenceTest nouvelleReference ("Jim Halpert", "Somehow I manage",
                                   2010, "ISBN 978-0-387-77591-3");
  ASSERT_FALSE (f_reference == nouvelleReference);
}


TEST_F (ReferenceValide, operateurTitreNE)
{
  ReferenceTest nouvelleReference ("Micheal Scott", "Somehow I do not manage",
                                   2010, "ISBN 978-0-387-77591-3");
  ASSERT_FALSE (f_reference == nouvelleReference);
}


TEST_F (ReferenceValide, operateurIdentifiantNE)
{
  ReferenceTest nouvelleReference ("Micheal Scott", "Somehow I manage",
                                   2010, "ISBN 978-3-16-148410-0");
  ASSERT_FALSE (f_reference == nouvelleReference);
}


/**
 * \brief Test de la méthode const std::string& reqAuteurs () const.
 *     Cas valide: reqAuteurs: Vérifie le retour du nom de l'auteur.
 *     Cas invalide: aucun à tester.
 */

TEST_F (ReferenceValide, reqAuteurs)
{
  ASSERT_EQ (f_reference.reqAuteurs (), "Micheal Scott");
}


/**
 * \brief Test de la méthode const std::string& reqTitre () const.
 *     Cas valide: reqTitre: Vérifie le retour du titre.
 *     Cas invalide: aucun à tester.
 */

TEST_F (ReferenceValide, reqTitre)
{
  ASSERT_EQ (f_reference.reqTitre (), "Somehow I manage");
}


/**
 * \brief Test de la méthode int reqAnnee () const.
 *     Cas valide: reqAnnee: Vérifie le retour du l'année.
 *     Cas invalide: aucun à tester.
 */

TEST_F (ReferenceValide, reqAnnee)
{
  ASSERT_EQ (f_reference.reqAnnee (), 2010);
}


/**
 * \brief Test de la méthode const std::string& reqIdentifiant () const.
 *     Cas valide: reqIdentifiant: Vérifie le retour du l'identifiant.
 *     Cas invalide: aucun à tester.
 */

TEST_F (ReferenceValide, reqIdentifiant)
{
  ASSERT_EQ (f_reference.reqIdentifiant (), "ISBN 978-0-387-77591-3");
}


/**
 * \brief Test de la méthode virtual std::string reqReferenceFormate () const = 0.
 *     Cas valide: reqReferenceFormate : Vérifie le retour du formatage d'une référence.
 *     Cas invalide: aucun à tester.
 */
TEST_F (ReferenceValide, reqReferenceFormate)
{
  ASSERT_EQ ("Micheal Scott. Somehow I manage. ", f_reference.reqReferenceFormate ());
}

