/**
 * \file BibliographieTesteur.cpp
 * \brief Test unitaire de la classe Bibliographie.
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 * A tester:
 *    Bibliographie (const std::string& p_nomBibliographie);
      Bibliographie (const Bibliographie& p_bibliographie);

      const std::string& reqNomBibliographie () const;
      void ajouterReference (const biblio::Reference& p_nouvelleReference);
      std::string reqBibliographieFormate () const;
      Bibliographie& operator= (const Bibliographie& p_bibliographie);
 */
#include <gtest/gtest.h>
#include "Bibliographie.h"
#include "Journal.h"
#include "Ouvrage.h"
#include <iostream>
#include <sstream>
#include "ContratException.h"

using namespace std;
using namespace biblio;


/**
 * \brief Test du constructeur avec paramètres Bibliographie (const string& p_nomBibliographie)
 *     Cas valide: constructeurValide Paramètre passé en paramètre valide.
 *     Cas invalide: constructeurInvalide p_nomBibliographie est vide.
 */
TEST (Bibliographie, constructeurValide)
{
  Bibliographie uneBibliographie ("Mes favoris");
  ASSERT_EQ ("Mes favoris", uneBibliographie.reqNomBibliographie ());
}


TEST (Bibliographie, constructeurInvalide)
{
  ASSERT_THROW (Bibliographie b1 (""), PreconditionException)
          << "Le nom de la bibliographie ne doit pas être vide.";
}

/**
 * \class BibliographieValide
 * \brief Création d'une fixture utilisé pour les tests de la classe Bibliographie
 */
class BibliographieValide : public ::testing::Test
{

public:


  BibliographieValide () :
  f_bibliographie ("Mes favoris"),
  f_ouvrage ("Micheal Scott", "Somehow I manage", 2010, "ISBN 978-0-387-77591-3",
             "Dunder Mifflin Editions", "Scranton")
  {
    f_bibliographie.ajouterReference (f_ouvrage);
  };

  Bibliographie f_bibliographie;
  Ouvrage f_ouvrage;
} ;


/**
 * \brief Test du constructeur copie Bibliographie (const Bibliographie& p_Bibliographie)
 *     Cas valide: constructeurCopieValide: Un constructeur de copie valide.
 *     Cas invalide: aucun à tester.
 */
TEST_F (BibliographieValide, ConstructeurCopieValide)
{
  Bibliographie uneCopie (f_bibliographie);
  ASSERT_EQ ("Mes favoris", uneCopie.reqNomBibliographie ());
  ASSERT_EQ (f_bibliographie.reqBibliographieFormate (), uneCopie.reqBibliographieFormate ());
}


/**
 * \brief Test de la méthode const std::string& reqNomBibliographie () const.
 *     Cas valide: reqNomBibliographie : Vérifie le retour du nom de la bibliographie.
 *     Cas invalide: aucun à tester.
 */
TEST_F (BibliographieValide, reqNomBibliographie)
{
  ASSERT_EQ ("Mes favoris", f_bibliographie.reqNomBibliographie ());
}


/**
 * \brief Test de la méthode void ajouterReference (const biblio::Reference& p_nouvelleReference).
 *     Cas valide:
 *          ajouterReferenceNonPresente : Ajoute Référence au vecteur de la classe Bibliographie
 *          ajouterReferenceDejaPresente: N'ajoute pas la référence au vecteur car la reférérence
 *                                        est déja présente.
 *     Cas invalide: aucun à tester.
 */
TEST_F (BibliographieValide, ajouterReferenceNonPresente)
{
  Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                     "The Journal of Apple", 13, 13, 113);

  f_bibliographie.ajouterReference (unJournal);

  ostringstream os;
  os << "Mes favoris" << endl << "===============================" << endl
          << "[1] Micheal Scott. Somehow I manage. Scranton : Dunder Mifflin Editions, 2010. "
          << "ISBN 978-0-387-77591-3." << endl
          << "[2] Steve Jobs. Hello World. The Journal of Apple, vol. 13, "
          << "no. 13, pp. 113, 1984. ISSN 1937-4771." << endl;

  ASSERT_EQ (os.str (), f_bibliographie.reqBibliographieFormate ());
}


TEST_F (BibliographieValide, ajouterReferenceDejaPresente)
{
  Ouvrage unOuvrage ("Micheal Scarn", "Threat Level Midnight", 2010, "ISBN 978-0-387-77591-3",
                     "Dunder Mifflin Editions", "Scranton");

  f_bibliographie.ajouterReference (unOuvrage);

  ostringstream os;
  os << "Mes favoris" << endl << "===============================" << endl
          << "[1] Micheal Scott. Somehow I manage. Scranton : Dunder Mifflin Editions, 2010. "
          << "ISBN 978-0-387-77591-3." << endl;

  ASSERT_EQ (os.str (), f_bibliographie.reqBibliographieFormate ());
}


/**
 * \brief Test de la méthode std::string reqBibliographieFormate () const.
 *     Cas valide: reqBibliographieFormate: Vérifie le retour de formattage d'une bibliographie.
 *     Cas invalide: aucun à tester.
 */
TEST_F (BibliographieValide, reqBibliographieFormate)
{
  Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                     "The Journal of Apple", 13, 13, 113);

  f_bibliographie.ajouterReference (unJournal);

  ostringstream os;
  os << "Mes favoris" << endl << "===============================" << endl
          << "[1] Micheal Scott. Somehow I manage. Scranton : Dunder Mifflin Editions, 2010. "
          << "ISBN 978-0-387-77591-3." << endl
          << "[2] Steve Jobs. Hello World. The Journal of Apple, vol. 13, "
          << "no. 13, pp. 113, 1984. ISSN 1937-4771." << endl;

  ASSERT_EQ (os.str (), f_bibliographie.reqBibliographieFormate ());
}


/**
 * \brief Test de la méthode Bibliographie& operator= (const Bibliographie& p_bibliographie).
 *     Cas valide: operateurAssignation: Vérifie la validité de l'opérateur assignation.
 *     Cas invalide: aucun à tester.
 */
TEST_F (BibliographieValide, operateurAssignation)
{
  Bibliographie nouvelleBibliographie ("Ma nouvelle bibliographie");
  Journal unJournal ("Steve Jobs", "Hello World", 1984, "ISSN 1937-4771",
                     "The Journal of Apple", 13, 13, 113);
  nouvelleBibliographie.ajouterReference (unJournal);

  nouvelleBibliographie = f_bibliographie;

  // Bibliographie devrait prendre le même nom que la fixture.
  ASSERT_EQ (f_bibliographie.reqNomBibliographie (), nouvelleBibliographie.reqNomBibliographie ());
  ASSERT_EQ (f_bibliographie.reqBibliographieFormate (), nouvelleBibliographie.reqBibliographieFormate ());
}


