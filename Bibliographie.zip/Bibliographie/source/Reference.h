/**
 * \file Reference.h
 * \brief Fichier d'interface de la classe Reference
 * \author Nicolas Gagné
 * \version 0.2
 * \date Livrable le 2022-12-01
 *
 * Programme d'interface de la classe Reference
 */

#ifndef REFERENCE_H
#define REFERENCE_H

#include <string>

namespace biblio
{

  /**
   * \class Reference
   * \brief Classe Reference permettant de modéliser des objets de
   *        références bibliographiques.
   */

  class Reference
  {
  public:
    Reference (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
               const std::string& p_identifiant);

    virtual
    ~Reference () { };
    void asgAnnee (int p_annee);
    bool operator== (const Reference& p_reference) const;
    const std::string& reqAuteurs () const;
    const std::string& reqTitre () const;
    int reqAnnee () const;
    const std::string& reqIdentifiant () const;
    virtual std::string reqReferenceFormate () const = 0;
    virtual Reference* clone () const = 0;


  private:
    std::string m_auteurs;
    std::string m_titre;
    int m_annee;
    std::string m_identifiant;
    void verifieInvariant () const;
  };

} // namespace bilio


#endif /* REFERENCE_H */

