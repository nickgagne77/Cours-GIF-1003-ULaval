/**
 * \file Journal.h
 * \brief Fichier d'interface de la classe Journal.
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 *
 * Programme d'interface de la classe Journal.
 */

#ifndef JOURNAL_H
#define JOURNAL_H

#include "Reference.h"
#include <string>

namespace biblio
{

  /**
   * \class Journal
   * \brief Classe qui représente les références de la catégorie Journal.
   */
  class Journal : public biblio::Reference
  {
  public:
    Journal (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
             const std::string& p_identifiant, const std::string& p_nom,
             int p_volume, int p_numero, int p_page);
    const std::string& reqNom () const;
    int reqVolume () const;
    int reqNumero () const;
    int reqPage () const;
    virtual std::string reqReferenceFormate () const;
    virtual Reference* clone () const;

  private:
    void verifieInvariant () const;
    std::string m_nom;
    int m_volume;
    int m_numero;
    int m_page;
  };
} // namespace biblio

#endif /* JOURNAL_H */


