/**
 * \file Journal.cpp
 * \brief Fichier d'implémentation de la classe Journal
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 *
 * Programme d'implémentation de la classe Journal
 */

#include "Journal.h"
#include <string>
#include <sstream>
#include <iostream>
#include "ContratException.h"
#include "validationFormat.h"

using namespace std;
using namespace util;
using namespace biblio;


/**
 * \brief Constructeur avec parametres d'un objet de type Journal
 * \param[in] p_auteurs Le nom de l'auteurs (ou du premier s'ils sont plusieurs)
 * \param[in] p_titre Le titre
 * \param[in] p_annee L'annee d'edition de la référence
 * \param[in] p_identifiant Code ISSN de la référence
 * \param[in] p_nom Le nom du journal dans laquelle a été publiée la référence.
 * \param[in] p_volume Le volume dans laquelle se situe la référence.
 * \param[in] p_numero LE numéro dans laquelle se situe la référence.
 * \param[in] p_page La page ou se trouve la reference.
 * \return Un objet Journal
 * \pre p_nom doit être dans un format valide.
 * \pre p_volume >= 0
 * \pre p_numero >= 0
 * \pre p_page >= 0
 * \post Vérification de l'attribut m_nom s'il contient le nom courant.
 * \post Vérification de l'attribut m_volume s'il contient le volume courant.
 * \post Vérification de l'attribut m_numero s'il contient le numero courant.
 * \post Vérification de l'attribut m_page s'il contient la page courante.
 */
Journal::Journal (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
                  const std::string& p_identifiant, const std::string& p_nom,
                  int p_volume, int p_numero, int p_page)
: Reference (p_auteurs, p_titre, p_annee, p_identifiant), m_nom (p_nom), m_volume (p_volume),
m_numero (p_numero), m_page (p_page)
{
  PRECONDITION (validerCodeIssn (p_identifiant));
  PRECONDITION (!p_nom.empty ());
  PRECONDITION (p_volume >= 0);
  PRECONDITION (p_numero >= 0);
  PRECONDITION (p_page >= 0);

  POSTCONDITION (m_nom == p_nom);
  POSTCONDITION (m_volume == p_volume);
  POSTCONDITION (m_numero == p_numero);
  POSTCONDITION (m_page == p_page);
  INVARIANTS ();
}


/**
 * \brief Accesseur pour l'attribut m_nom
 * \return m_nom  Le nom du journal de l'objet courant.
 */
const std::string &
Journal::reqNom () const
{
  return m_nom;
}


/**
 * \brief Accesseur pour m_volume
 * \return m_volume Le volume de l'objet Journal
 */
int
Journal::reqVolume () const
{
  return m_volume;
}


/**
 * \brief Accesseur pour m_numero
 * \return m_numero Le numero de l'objet Journal
 */
int
Journal::reqNumero () const
{
  return m_numero;
}


/**
 * \brief Accesseur pour m_page
 * \return m_page La page ou se trouve la reference de l'objet Journal.
 */
int
Journal::reqPage () const
{
  return m_page;
}


/**
 * \brief Retourne une chaine de caractere qui contient l'information de l'objet Journal
 * \return un string qui contient l'information formatee sur l'objet Journal courant.
 */
std::string
Journal::reqReferenceFormate () const
{
  std::ostringstream os;
  os << Reference::reqReferenceFormate ();
  os << reqNom () << ", ";
  os << "vol. " << reqVolume () << ", ";
  os << "no. " << reqNumero () << ", ";
  os << "pp. " << reqPage () << ", ";
  os << Reference::reqAnnee () << ". ";
  os << Reference::reqIdentifiant () << ".";
  return os.str ();
}


/*
 * \brief Méthode permettant de faire une copie allouée sur le monceau de l'objet courant.
 */
Reference*
Journal::clone () const
{
  return new Journal (*this); // Appel du constructeur copie
}


/*
 * \brief Vérifier les invariants de la classe Ouvrage.
 *        m_nom doit être toujours valide.
 *        m_volume doit toujours être supérieur ou égal à 0.
 *        m_numero doit toujours être supérieur ou égal à 0.
 *        m_page doit toujours être supérieur ou égal à 0.
 */
void
Journal::verifieInvariant () const
{
  INVARIANT (!m_nom.empty ());
  INVARIANT (m_volume >= 0);
  INVARIANT (m_numero >= 0);
  INVARIANT (m_page >= 0);
}





