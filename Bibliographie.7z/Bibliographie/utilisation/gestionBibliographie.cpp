/**
 * \file gestionBibliographie.cpp
 * \brief Programme minimaliste qui utilise la classe Bibliographie
 *        avec les différents types de Reference.
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 */

#include <iostream>
#include <string>
#include "Bibliographie.h"
#include "ContratException.h"
#include "Journal.h"
#include "Ouvrage.h"
#include "Reference.h"
#include "validationFormat.h"

using namespace std;
using namespace util;
using namespace biblio;


/*
 * \fn string demanderAuteur ()
 * \brief Fonction qui demande l'auteur à l'utilisateur
 * \return un objet string qui est le nom de l'auteur
 */
string
demanderAuteur ()
{
  bool auteurValide = false;
  string entreeAuteur;

  do
    {
      cout << "Entrez le nom du ou des auteurs: " << endl;
      char buffer[256];
      cin.getline (buffer, 256);
      entreeAuteur = buffer;
      if (!entreeAuteur.empty ())
        {
          if (validerFormatNom (entreeAuteur))
            {
              auteurValide = true;
            }
          else
            {
              cout << "Le nom des auteurs n'est pas valide, recommencez." << endl;
            }
        }
      else
        {
          cout << "Le nom des auteurs ne doit pas être vide, recommencez." << endl;
        }
    }
  while (!auteurValide);

  return entreeAuteur;
}


/*
 * \fn string demanderTitre ()
 * \brief Fonction qui demande le titre à l'utilisateur
 * \return un objet string qui est le titre
 */
string
demanderTitre ()
{
  bool titreValide = false;
  string entreeTitre;

  do
    {
      cout << "Entrez le titre (sans ponctuation): " << endl;
      char buffer[256];
      cin.getline (buffer, 256);
      entreeTitre = buffer;
      if (!entreeTitre.empty ())
        {
          titreValide = true;
        }
      else
        {
          cout << "Le titre ne doit pas être vide, recommencez." << endl;
        }
    }
  while (!titreValide);

  return entreeTitre;
}


/*
 * \fn int demanderAnnee ()
 * \brief Fonction qui demande l'année à l'utilisateur
 * \return un objet int qui est l'année
 */
int
demanderAnnee ()
{
  bool anneeValide = false;
  int entreeAnnee;

  do
    {
      cout << "Entrez l'année: " << endl;
      cin >> entreeAnnee;
      cin.ignore (256, '\n');
      if ( entreeAnnee > 0)
        {
          anneeValide = true;
        }
      else
        {
          cout << "L'année doit être supérieure à 0, recommencez." << endl;
        }
    }
  while (!anneeValide);

  return (int) entreeAnnee;
}


/*
 * \fn string demanderCodeIsbn ()
 * \brief Fonction qui demande le code ISBN à l'utilisateur
 * \return un objet string qui est l'identifiant ISBN
 */
string
demanderCodeIsbn ()
{
  bool identifiantValide = false;
  string entreeIdentifiant;

  do
    {
      cout << "Entrez le code ISBN: " << endl;
      char buffer[256];
      cin.getline (buffer, 256);
      entreeIdentifiant = buffer;
      if (!entreeIdentifiant.empty ())
        {
          if (entreeIdentifiant.substr (0, 4) == "ISBN")
            {
              if (validerCodeIsbn (entreeIdentifiant))
                {
                  identifiantValide = true;
                }
              else
                {
                  cout << "Le code ISBN n'est pas valide, recommencez." << endl;
                }
            }
          else
            {
              cout << "Le code ISBN n'est pas valide, recommencez." << endl;
            }
        }
      else
        {
          cout << "Le code ISBN ne doit pas être vide, recommencez." << endl;
        }
    }
  while (!identifiantValide);

  return entreeIdentifiant;
}


/*
 * \fn string demanderCodeIssn ()
 * \brief Fonction qui demande le code ISSN à l'utilisateur
 * \return un objet string qui est l'identifiant ISSN
 */
string
demanderCodeIssn ()
{
  bool identifiantValide = false;
  string entreeIdentifiant;

  do
    {
      cout << "Entrez le code ISSN: " << endl;
      char buffer[256];
      cin.getline (buffer, 256);
      entreeIdentifiant = buffer;
      if (!entreeIdentifiant.empty ())
        {
          if (entreeIdentifiant.substr (0, 4) == "ISSN")
            {
              if (validerCodeIssn (entreeIdentifiant))
                {
                  identifiantValide = true;
                }
              else
                {
                  cout << "Le code ISSN n'est pas valide, recommencez." << endl;
                }
            }
          else
            {
              cout << "Le code ISSN n'est pas valide, recommencez." << endl;
            }
        }
      else
        {
          cout << "Le code ISSN ne doit pas être vide, recommencez." << endl;
        }
    }
  while (!identifiantValide);

  return entreeIdentifiant;
}


/*
 * \fn string demanderEditeur ()
 * \brief Fonction qui demande le nom de l'éditeur à l'utilisateur
 * \return un objet string qui est le nom de l'éditeur
 */
string
demanderEditeur ()
{
  bool editeurValide = false;
  string entreeEditeur;

  do
    {
      cout << "Entrez l'éditeur: " << endl;
      char buffer[256];
      cin.getline (buffer, 256);
      entreeEditeur = buffer;
      if (!entreeEditeur.empty ())
        {
          if (validerFormatNom (entreeEditeur))
            {
              editeurValide = true;
            }
          else
            {
              cout << "Le nom de l'éditeur n'est pas valide, recommencez." << endl;
            }
        }
      else
        {
          cout << "Le nom de l'éditeur ne doit pas être vide, recommencez." << endl;
        }
    }
  while (!editeurValide);

  return entreeEditeur;
}


/*
 * \fn string demanderVille ()
 * \brief Fonction qui demande la ville d'édition à l'utilisateur
 * \return un objet string qui est la ville d'édition.
 */
string
demanderVille ()
{
  bool villeValide = false;
  string entreeVille;

  do
    {
      cout << "Entrez la ville d'édition " << endl;
      char buffer[256];
      cin.getline (buffer, 256);
      entreeVille = buffer;
      if (!entreeVille.empty ())
        {
          if (validerFormatNom (entreeVille))
            {
              villeValide = true;
            }
          else
            {
              cout << "La ville d'édition n'est pas valide, recommencez." << endl;
            }
        }
      else
        {
          cout << "La ville d'édition ne doit pas être vide, recommencez." << endl;
        }
    }
  while (!villeValide);

  return entreeVille;
}


/*
 * \fn string demanderNom ()
 * \brief Fonction qui demande le nom du Journal à l'utilisateur
 * \return un objet string qui est le nom du Journal .
 */
string
demanderNom ()
{
  bool nomValide = false;
  string entreeNom;

  do
    {
      cout << "Entrez le nom de la revue dans laquelle a été publiée la référence:" << endl;
      char buffer[256];
      cin.getline (buffer, 256);
      entreeNom = buffer;
      if (!entreeNom.empty ())
        {
          nomValide = true;
        }
      else
        {
          cout << "Le nom de la revue ne doit pas être vide, recommencez." << endl;
        }
    }
  while (!nomValide);

  return entreeNom;
}


/*
 * \fn int demanderVolume ()
 * \brief Fonction qui demande le volume de la référence à l'utilisateur
 * \return un objet int qui est le volume de la référence
 */
int
demanderVolume ()
{
  bool volumeValide = false;
  int entreeVolume;

  do
    {
      cout << "Entrez le volume: " << endl;
      cin >> entreeVolume;
      cin.ignore (256, '\n');
      if ( entreeVolume > 0)
        {
          volumeValide = true;
        }
      else
        {
          cout << "Le volume doit être supérieure à 0, recommencez." << endl;
        }
    }
  while (!volumeValide);

  return (int) entreeVolume;
}


/*
 * \fn int demanderNumero ()
 * \brief Fonction qui demande le numéro de la revue à l'utilisateur
 * \return un objet int qui est le numéro de la revue
 */
int
demanderNumero ()
{
  bool numeroValide = false;
  int entreeNumero;

  do
    {
      cout << "Entrez le numéro: " << endl;
      cin >> entreeNumero;
      cin.ignore (256, '\n');
      if ( entreeNumero > 0)
        {
          numeroValide = true;
        }
      else
        {
          cout << "Le numéro doit être supérieure à 0, recommencez." << endl;
        }
    }
  while (!numeroValide);

  return (int) entreeNumero;
}


/*
 * \fn int demanderPage ()
 * \brief Fonction qui demande la page où commence la référence à l'utilisateur
 * \return un objet int qui est la page où commence la référence
 */
int
demanderPage ()
{
  bool pageValide = false;
  int entreePage;

  do
    {
      cout << "Entrez la page où commence la référence: " << endl;
      cin >> entreePage;
      cin.ignore (256, '\n');
      if ( entreePage > 0)
        {
          pageValide = true;
        }
      else
        {
          cout << "La page doit être supérieure à 0, recommencez." << endl;
        }
    }
  while (!pageValide);

  return (int) entreePage;
}


/**
 * \fn Fonction Ouvrage creerOuvrage().
 * \brief Fonction qui retourne un objet Ouvrage en demandant les entrees à l'utilisateur.
 * \return un objet reference de type Ouvrage.
 */
Ouvrage
creerOuvrage ()
{
  string auteur = demanderAuteur ();
  string titre = demanderTitre ();
  string ville = demanderVille ();
  string editeur = demanderEditeur ();
  int annee = demanderAnnee ();
  string identifiant = demanderCodeIsbn ();

  Ouvrage ouvrageEntree (auteur, titre, annee, identifiant, editeur, ville);
  return ouvrageEntree;
}


/**
 * \fn Fonction Journal creerJournal ()
 * \brief Fonction qui retourne un objet Journal en demandant les entrees à l'utilisateur.
 * \return un objet reference de type Journal.
 */
Journal
creerJournal ()
{
  string auteur = demanderAuteur ();
  string titre = demanderTitre ();
  string nom = demanderNom ();
  int volume = demanderVolume ();
  int numero = demanderNumero ();
  int page = demanderPage ();
  int annee = demanderAnnee ();
  string identifiant = demanderCodeIssn ();

  Journal journalEntree (auteur, titre, annee, identifiant, nom, volume, numero, page);
  return journalEntree;
}


/**
 * \brief Programme principal
 */
int
main (void)
{
  Bibliographie uneBibliographie ("Bibliographie");
  cout << "Bienvenue dans l'outil de gestion de références bibliographiques" << endl;
  cout << "================================================================" << endl;
  cout << "-------------------------------------------------------" << endl;
  cout << "Ajoutez un ouvrage" << endl;
  cout << "-------------------------------------------------------" << endl;
  Ouvrage unOuvrage = creerOuvrage ();
  uneBibliographie.ajouterReference (unOuvrage);

  cout << endl;
  cout << "-------------------------------------------------------" << endl;
  cout << "Ajoutez une référence de type article de journal" << endl;
  cout << "-------------------------------------------------------" << endl;
  Journal unJournal = creerJournal ();
  uneBibliographie.ajouterReference (unJournal);

  cout << endl;
  cout << "Références bibliographiques enregistrées: " << endl;
  cout << uneBibliographie.reqBibliographieFormate ();

  cout << endl;
  cout << "Fin du programme! :)";

  return 0;
}



