/**
 * \file Ouvrage.h
 * \brief Fichier d'interface de la classe Ouvrage.
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 *
 * Programme d'interface de la classe Ouvrage.
 */

#ifndef OUVRAGE_H
#define OUVRAGE_H

#include <string>
#include "Reference.h"

namespace biblio
{

  /**
   * \class Ouvrage
   * \brief Classe qui représente les références de la catégorie Ouvrage.
   */
  class Ouvrage : public biblio::Reference
  {
  public:
    Ouvrage (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
             const std::string& p_identifiant, const std::string& p_editeur,
             const std::string& p_ville);
    const std::string& reqEditeur () const;
    const std::string& reqVille () const;
    virtual std::string reqReferenceFormate () const;
    virtual Reference* clone () const;


  private:
    void verifieInvariant () const;

    std::string m_editeur;
    std::string m_ville;
  };
} // namespace biblio
#endif /* OUVRAGE_H */
