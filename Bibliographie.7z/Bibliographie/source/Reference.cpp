/**
 * \file Reference.cpp
 * \brief Fichier d'implémentation de la classe Reference
 * \author Nicolas Gagné
 * \version 0.2
 * \date Livrable le 2022-12-01
 *
 * Programme d'implémentation de la classe Reference
 */
#include "Reference.h"
#include "validationFormat.h"
#include <string>
#include <sstream>
#include <iostream>
#include "ContratException.h"

using namespace std;
using namespace util;
namespace biblio
{


  /**
   * \brief Constructeur avec parametres d'un objet de type Reference
   * \param[in] p_auteurs Le nom de l'auteurs (ou du premier s'ils sont plusieurs)
   * \param[in] p_titre Le titre
   * \param[in] p_annee L'annee d'edition de la référence
   * \param[in] p_identifiant Code ISSN ou ISBN de la référence
   * \return Un objet Reference
   * \pre p_auteurs doit être dans un format valide et non vide.
   * \pre p_titre ne doit pas être vide.
   * \pre p_annee > 0
   * \pre p_identifiant doit être dans un format valide (Vérifié dans les classes dérivées)
   * \post Vérification de l'attribut m_auteurs s'il contient l'auteur courant.
   * \post Vérification de l'attribut m_titre s'il contient le titre courant.
   * \post Vérification de l'attribut m_annee s'il contient l'annee courante.
   * \post Vérification de l'attribut m_identifiant s'il contient l'identifiant courant.
   */
  Reference::Reference (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
                        const std::string& p_identifiant)
  : m_auteurs (p_auteurs), m_titre (p_titre), m_annee (p_annee), m_identifiant (p_identifiant)
  {
    PRECONDITION (validerFormatNom (p_auteurs) && !p_auteurs.empty ());
    PRECONDITION (!p_titre.empty ());
    PRECONDITION (p_annee > 0);
    PRECONDITION (!p_identifiant.empty ());

    POSTCONDITION (m_auteurs == p_auteurs);
    POSTCONDITION (m_titre == p_titre);
    POSTCONDITION (m_annee == p_annee);
    POSTCONDITION (m_identifiant == p_identifiant);
    INVARIANTS ();
  }


  /**
   * \brief Accesseur pour auteurs
   * \return m_auteurs L'auteur de l'objet Reference
   */
  const std::string&
  Reference::reqAuteurs () const
  {
    return m_auteurs;
  }


  /**
   * \brief Accesseur pour titre
   * \return m_titre Le titre de l'objet Reference
   */
  const std::string&
  Reference::reqTitre () const
  {
    return m_titre;
  }


  /**
   * \brief Accesseur pour annee
   * \return m_annee L'annee de l'objet Reference
   */
  int
  Reference::reqAnnee () const
  {
    return m_annee;
  }


  /**
   * \brief Accesseur pour annee
   * \return m_annee L'annee de l'objet Reference
   */
  const std::string&
  Reference::reqIdentifiant () const
  {
    return m_identifiant;
  }


  /**
   * \brief Mutateur pour annee, modifie l'annee d'édition de la référence
   * \param[in] p_annee nouvellee annee
   * \pre p_annee > 0.
   * \post m_annee prend la valeur de p_annee.
   */
  void
  Reference::asgAnnee (int p_annee)
  {
    PRECONDITION (p_annee > 0);

    m_annee = p_annee;

    POSTCONDITION (m_annee == p_annee);
    INVARIANTS ();
  }


  /**
   * \brief Retourne une chaine de caractere qui contient l'information de l'objet Reference
   *        C'est une méthode virtuelle pure permettant l'abstraction de la classe Reference.
   * \return un string qui contient l'information formatee
   */
  std::string
  Reference::reqReferenceFormate () const
  {
    ostringstream os;
    os << reqAuteurs () << ". ";
    os << reqTitre () << ". ";
    return os.str ();
  }


  /**
   * \brief surcharge de l'opérateur ==
   * \param[in] p_reference à comparer à la référence courante
   * \return un booléen indiquant si les deux références sont égales ou non
   */
  bool Reference::operator== (const Reference& p_reference) const
  {
    return (m_auteurs == p_reference.m_auteurs
            && m_titre == p_reference.m_titre
            && m_annee == p_reference.m_annee
            && m_identifiant == p_reference.m_identifiant);
  }


  /*
   * \brief Vérifier les invariants de la classe Référence.
   *        m_auteurs doit être toujours valide.
   *        m_titre ne doit jamais être vide.
   *        m_annee doit toujours être supérieur à 0.
   *        m_identifiant ne doit jamais être vide.
   */
  void
  Reference::verifieInvariant () const
  {
    INVARIANT (validerFormatNom (m_auteurs) && !m_auteurs.empty ());
    INVARIANT (!m_titre.empty ());
    INVARIANT (m_annee > 0);
    INVARIANT (!m_identifiant.empty ());
  }
} // namespace biblio
