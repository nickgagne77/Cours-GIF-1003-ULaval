/**
 * \file Bibliographie.cpp
 * \brief Fichier d'implémentation de la classe Bibliographie
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 *
 * Programme d'implémentation de la classe Bibliographie
 */

#include "Bibliographie.h"
#include <string>
#include <sstream>
#include <iostream>
#include <vector>
#include "ContratException.h"
#include "validationFormat.h"

using namespace std;
using namespace util;
using namespace biblio;


/**
 * \brief Constructeur avec parametres d'un objet de type Bibliographie
 * \param[in] p_nomBibliographie Le nom du regroupement de Bibliographies
 * \return Un objet Bibliographie
 * \pre p_nomBibliographie ne doit pas être vide.
 * \post Vérification de l'attribut m_nomBibliographie s'il contient le nom courant.
 * \post Vérification de l'attribut m_vReference s'il est bien vide au départ.
 */
Bibliographie::Bibliographie (const std::string& p_nomBibliographie)
: m_nomBibliographie (p_nomBibliographie)
{
  PRECONDITION (!p_nomBibliographie.empty ());
  POSTCONDITION (m_nomBibliographie == p_nomBibliographie);
  POSTCONDITION (m_vReferences.empty ());
  INVARIANTS ();
}


/**
 * \brief Constructeur copie pour la classe Bibliographie
 * \post Vérification de l'attribut m_nomBibliographie s'il contient le nom courant.
 * \post Vérification de l'attribut m_vReference s'il est bien vide au départ.
 */
Bibliographie::Bibliographie (const Bibliographie& p_bibliographie)
{
  m_nomBibliographie = p_bibliographie.m_nomBibliographie;
  copierVecteur (p_bibliographie);

  POSTCONDITION (m_nomBibliographie == p_bibliographie.m_nomBibliographie);
  INVARIANTS ();
}


/*
 * \brief Destructeur de la classe Bibliographie qui désalloue toutes les References du vecteur.
 * \post Le Vecteur de référence doit être vidé.
 */
Bibliographie::~Bibliographie ()
{
  this->viderVecteur ();
  //POSTCONDITION (m_vReferences[0] == nullptr);
  //INVARIANTS ();
}


/**
 * \brief Accesseur pour Le nom du regroupement de Bibliographies
 * \return m_nomBibliographie Le de l'objet Bibliographie courant.
 */
const std::string&
Bibliographie::reqNomBibliographie () const
{


  return m_nomBibliographie;
}


/**
 * \brief Méthode qui permet d'ajouter une Reference au vecteurs des References
 * \return m_titre Le titre de l'objet Reference
 * \pre la reference passée en argument ne doit pas être déja présente
 * \post Le vecteur de référence ne doit pas être vide.
 */
void
Bibliographie::ajouterReference (const Reference& p_nouvelleReference)
{
  if (!referenceEstDejaPresente (p_nouvelleReference.reqIdentifiant ()))
    {
      m_vReferences.push_back (p_nouvelleReference.clone ());
    }
  POSTCONDITION (!m_vReferences.empty ());
  INVARIANTS ();
}


/**
 * \brief Retourne une chaine de caractere qui contient l'information du vecteurs de References
 * \return un string qui contient l'information formatee
 */
std::string
Bibliographie::reqBibliographieFormate () const
{
  ostringstream os;
  os << reqNomBibliographie () << endl;
  os << "===============================" << endl;

  for (unsigned int i = 0; i < m_vReferences.size (); i++)
    {
      os << '[' << i + 1 << "] ";
      os << m_vReferences[i]->reqReferenceFormate () << endl;
    }

  return os.str ();
}


// A VALIDER TODO


/**
 * \brief Surcharge de l'opérateur = pour assigner une Bibliographie
 * \pre Le vecteur de référence doit être vide.
 * \param [in] Un objet de type Bibliographie.
 * \return La bibliographie
 */
Bibliographie& Bibliographie::operator = (const Bibliographie& p_bibliographie)
{
  m_nomBibliographie = p_bibliographie.m_nomBibliographie;
  viderVecteur ();
  copierVecteur (p_bibliographie);
  INVARIANTS ();
  return *this;
}


/**
 * \brief Méthode qui indique si une Reference est déjà dans le vecteur de bibliographies.
 * \return un bool qui indique la valeur de vérité si la Reference est déjà presente ou non.
 */
bool
Bibliographie::referenceEstDejaPresente (const std::string& p_identifiant) const
{
  bool estPresente = false;

  for (unsigned int i = 0; i < m_vReferences.size (); i++)
    {
      if (m_vReferences[i]->reqIdentifiant () == p_identifiant)
        {
          estPresente = true;
          break;
        }
    }

  return estPresente;
}


// A VALIDER TODO


/**
 * \brief Retourne une chaine de caractere qui contient l'information du vecteurs de References
 * \pre Le vecteur de référence doit être vide.
 * \param [in] Un objet de type Bibliographie.
 */
void
Bibliographie::copierVecteur (const Bibliographie& p_bibliographie)
{
  PRECONDITION (m_vReferences.empty ());

  for (unsigned int i = 0; i < p_bibliographie.m_vReferences.size (); i++)
    {
      ajouterReference (*p_bibliographie.m_vReferences[i]);
    }
  INVARIANTS ();
}


//A VALIDER TODO


/**
 * \brief Méthode qui libère les ressources du vecteur, puis vide le vecteur.
 */
void
Bibliographie::viderVecteur ()
{
  for (unsigned int i = 0; i < m_vReferences.size (); i++)
    {
      delete m_vReferences[i];
    }
  m_vReferences.clear ();

  INVARIANTS ();
}


/*
 * \brief Vérifier les invariants de la classe Référence.
 */
void
Bibliographie::verifieInvariant () const
{
  INVARIANT (!m_nomBibliographie.empty ());
}


