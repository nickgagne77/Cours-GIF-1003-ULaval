var searchData=
[
  ['postconditionexception_24',['PostconditionException',['../class_postcondition_exception.html',1,'PostconditionException'],['../class_postcondition_exception.html#acc95ea17c4302b996261b7201d2cf6c4',1,'PostconditionException::PostconditionException()']]],
  ['preconditionexception_25',['PreconditionException',['../class_precondition_exception.html',1,'PreconditionException'],['../class_precondition_exception.html#a66d4b4c57a0675d487dab85d2c31b08c',1,'PreconditionException::PreconditionException()']]]
];
