var searchData=
[
  ['journal_54',['Journal',['../classbiblio_1_1_journal.html',1,'biblio']]],
  ['journalvalide_55',['JournalValide',['../class_journal_valide.html',1,'']]]
];
