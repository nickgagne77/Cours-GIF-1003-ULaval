var searchData=
[
  ['journal_84',['Journal',['../classbiblio_1_1_journal.html#a31b572898583d0c0addbf7a7278dfd81',1,'biblio::Journal']]]
];
