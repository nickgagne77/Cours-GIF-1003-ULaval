/**
 * \file OuvrageTesteur.cpp
 * \brief Test unitaire de la classe Ouvrage
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 * A tester:
 *      Ouvrage (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
             const std::string& p_identifiant, const std::string& p_editeur,
             const std::string& p_ville);
        const std::string& reqEditeur () const;
        const std::string& reqVille () const;
        virtual std::string reqReferenceFormate () const;
        virtual Reference* clone () const;
 *
 */
#include <gtest/gtest.h>
#include <iostream>
#include <sstream>
#include "Ouvrage.h"
#include "Reference.h"
#include "ContratException.h"
#include "validationFormat.h"

using namespace std;
using namespace util;
using namespace biblio;


/**
 * \brief Test du constructeur avec paramètres Ouvrage (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
             const std::string& p_identifiant, const std::string& p_editeur,
             const std::string& p_ville)
 *     Cas valide: ConstructeurValide Tous les paramètres sont valides.
 *     Cas invalides: ConstructeurAuteursInvalide : L'auteur est invalide.
 *                    ConstructeurTitreVide Le titre est vide.
 *                    ConstructeurAnneeInvalide L'année est inférieure à 0.
 *                    ConstructeurIdentifiantInvalide L'identifiant est invalide.
 *                    ConstructeurEditeurInvalide Le nom d'éditeur est invalide.
 *                    ConstructeurVilleInvalide L'identifiant est invalide.
 */

TEST (Ouvrage, ConstructeurValide)
{
  Ouvrage unOuvrage ("Micheal Scott", "Somehow I manage", 2010, "ISBN 978-0-387-77591-3",
                     "Dunder Mifflin Editions", "Scranton");

  ASSERT_EQ ("Micheal Scott", unOuvrage.reqAuteurs ());
  ASSERT_EQ ("Somehow I manage", unOuvrage.reqTitre ());
  ASSERT_EQ (2010, unOuvrage.reqAnnee ());
  ASSERT_EQ ("ISBN 978-0-387-77591-3", unOuvrage.reqIdentifiant ());
  ASSERT_EQ ("Dunder Mifflin Editions", unOuvrage.reqEditeur ());
  ASSERT_EQ ("Scranton", unOuvrage.reqVille ());

  ASSERT_TRUE (validerFormatNom (unOuvrage.reqAuteurs ()));
  ASSERT_TRUE (!unOuvrage.reqTitre ().empty ());
  ASSERT_TRUE (unOuvrage.reqAnnee () > 0);
  ASSERT_TRUE (validerCodeIsbn (unOuvrage.reqIdentifiant ()));
  ASSERT_TRUE (validerFormatNom (unOuvrage.reqEditeur ()));
  ASSERT_TRUE (validerFormatNom (unOuvrage.reqVille ()));
}


TEST (Ouvrage, ConstructeurAuteursInvalide)
{
  ASSERT_THROW (Ouvrage unOuvrage ("Micheal    Scott", "Somehow I manage", 2010, "ISBN 978-0-387-77591-3",
                                   "Dunder Mifflin Editions", "Scranton"), PreconditionException)
          << "L'auteur doit être valide.";
}


TEST (Ouvrage, ConstructeurTitreVide)
{
  ASSERT_THROW (Ouvrage unOuvrage ("Micheal Scott", "", 2010, "ISBN 978-0-387-77591-3",
                                   "Dunder Mifflin Editions", "Scranton"), PreconditionException)
          << "Le titre ne doit pas être vide.";
}


TEST (Ouvrage, ConstructeurAnneeInvalide)
{
  ASSERT_THROW (Ouvrage unOuvrage ("Micheal Scott", "Somehow I manage", 0, "ISBN 978-0-387-77591-3",
                                   "Dunder Mifflin Editions", "Scranton"), PreconditionException)
          << "L'année doit être supérieure à 0.";
}


TEST (Ouvrage, ConstructeurIdentifiantInvalide)
{
  ASSERT_THROW (Ouvrage unOuvrage ("Micheal Scott", "Somehow I manage", 2010, "ISBN 123-0-387-77591-3",
                                   "Dunder Mifflin Editions", "Scranton"), PreconditionException)
          << "L'identifiant doit être valide.";
}


TEST (Ouvrage, ConstructeurEditeurInvalide)
{
  ASSERT_THROW (Ouvrage unOuvrage ("Micheal Scott", "Somehow I manage", 0, "ISBN 978-0-387-77591-3",
                                   "Dunder Mifflin Ed...", "Scranton"), PreconditionException)
          << "Le nom de l'éditeur doit être valide.";
}


TEST (Ouvrage, ConstructeurVilleInvalide)
{
  ASSERT_THROW (Ouvrage unOuvrage ("Micheal Scott", "Somehow I manage", 2010, "ISBN 978-0-387-77591-3",
                                   "Dunder Mifflin Editions", "Scranton!!!"), PreconditionException)
          << "Le nom de la ville doit être valide.";
}

/**
 * \class OuvrageValide
 * \brief Création d'une fixture utilisé pour les tests de la classe Ouvrage
 */
class OuvrageValide : public ::testing::Test
{

public:


  OuvrageValide () :
  f_ouvrage ("Micheal Scott", "Somehow I manage", 2010, "ISBN 978-0-387-77591-3",
             "Dunder Mifflin Editions", "Scranton") { };


  Ouvrage f_ouvrage;
} ;


/**
 * \brief Test de la méthode const std::string& reqEditeur () const.
 *     Cas valide: reqEditeur: Vérifie le retour du nom d'éditeur.
 *     Cas invalide: aucun à tester.
 */

TEST_F (OuvrageValide, reqEditeur)
{
  ASSERT_EQ (f_ouvrage.reqEditeur (), "Dunder Mifflin Editions");
}


/**
 * \brief Test de la méthode const std::string& reqVille () const.
 *     Cas valide: reqVille: Vérifie le retour du nom de la ville.
 *     Cas invalide: aucun à tester.
 */

TEST_F (OuvrageValide, reqVille)
{
  ASSERT_EQ (f_ouvrage.reqVille (), "Scranton");
}


/**
 * \brief Test de la méthode virtual std::string reqReferenceFormate () const.
 *     Cas valide: reqReferenceFormate : Vérifie le retour du formatage d'un ouvrage.
 *     Cas invalide: aucun à tester.
 */
TEST_F (OuvrageValide, reqReferenceFormate)
{
  ostringstream os;
  os << "Micheal Scott. Somehow I manage. "
          << "Scranton : Dunder Mifflin Editions, 2010. "
          << "ISBN 978-0-387-77591-3.";
  ASSERT_EQ (os.str (), f_ouvrage.reqReferenceFormate ());
}


/**
 * \brief Test de la méthode virtual Reference* clone () const;.
 *     Cas valide: cloneValide: Vérifie l'objet *unClone est identique à f_ouvrage.
 *     Cas invalide: aucun.
 */
TEST_F (OuvrageValide, cloneValide)
{
  Reference* unClone = f_ouvrage.clone ();

  ASSERT_EQ (f_ouvrage.reqAuteurs (), unClone->reqAuteurs ());
  ASSERT_EQ (f_ouvrage.reqTitre (), unClone->reqTitre ());
  ASSERT_EQ (f_ouvrage.reqAnnee (), unClone->reqAnnee ());
  ASSERT_EQ (f_ouvrage.reqIdentifiant (), unClone->reqIdentifiant ());
  ASSERT_EQ (f_ouvrage.reqReferenceFormate (), unClone->reqReferenceFormate ());

  delete unClone;
}

