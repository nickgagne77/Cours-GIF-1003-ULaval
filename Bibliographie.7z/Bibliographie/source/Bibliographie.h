/**
 * \file Bibliographie.h
 * \brief Fichier d'interface de la classe Bibliographie
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 *
 * Programme d'interface de la classe Bibliographie
 */

#ifndef BIBLIOGRAPHIE_H
#define BIBLIOGRAPHIE_H

#include <string>
#include <vector>
#include "Reference.h"

namespace biblio
{

  /**
   * \class Bibliographie
   * \brief Classe qui permet de faire la gestion des References.
   */
  class Bibliographie
  {
  public:
    Bibliographie (const std::string& p_nomBibliographie);
    Bibliographie (const Bibliographie& p_bibliographie);
    ~Bibliographie ();

    const std::string& reqNomBibliographie () const;
    void ajouterReference (const Reference& p_nouvelleReference);
    std::string reqBibliographieFormate () const;
    Bibliographie& operator= (const Bibliographie& p_bibliographie);

  private:
    bool referenceEstDejaPresente (const std::string& p_identifiant) const;
    void copierVecteur (const Bibliographie& p_bibliographie); // a valider
    void viderVecteur (); // a valider
    void verifieInvariant () const;

    std::string m_nomBibliographie;
    std::vector<Reference*> m_vReferences;
  };

} // namespace biblio

#endif /* BIBLIOGRAPHIE_H */

