/**
 * \file Ouvrage.cpp
 * \brief Fichier d'implémentation de la classe Ouvrage
 * \author Nicolas Gagné
 * \version 0.1
 * \date Livrable le 2022-12-01
 *
 * Programme d'implémentation de la classe Ouvrage
 */

#include "Ouvrage.h"
#include <string>
#include <sstream>
#include <iostream>
#include "ContratException.h"
#include "validationFormat.h"

using namespace std;
using namespace util;
using namespace biblio;


/**
 * \brief Constructeur avec parametres d'un objet de type Ouvrgae
 * \param[in] p_auteurs Le nom de l'auteurs (ou du premier s'ils sont plusieurs)
 * \param[in] p_titre Le titre
 * \param[in] p_annee L'annee d'edition de la référence
 * \param[in] p_identifiant Code ISSN ou ISBN de la référence
 * \param[in] p_editeur Le nom de l'éditeur de l'ouvrage
 * \param[in] p_ville La ville d'édition de l'ouvrage
 * \return Un objet Ouvrage
 * \pre p_editeur doit être dans un format valide et non vide.
 * \pre p_ville doit être dans un format valide et non vide.
 * \post Vérification de l'attribut m_editeur s'il contient l'éditeur courant.
 * \post Vérification de l'attribut m_ville s'il contient la ville courante.
 */
Ouvrage::Ouvrage (const std::string& p_auteurs, const std::string& p_titre, int p_annee,
                  const std::string& p_identifiant, const std::string& p_editeur,
                  const std::string& p_ville)
: Reference (p_auteurs, p_titre, p_annee, p_identifiant), m_editeur (p_editeur), m_ville (p_ville)
{
  PRECONDITION (validerCodeIsbn (p_identifiant));
  PRECONDITION (validerFormatNom (p_editeur) && !p_editeur.empty ());
  PRECONDITION (validerFormatNom (p_ville) && !p_ville.empty ());

  POSTCONDITION (m_editeur == p_editeur);
  POSTCONDITION (m_ville == p_ville);
  INVARIANTS ();
}


/**
 * \brief Accesseur pour l'attribut m_editeur
 * \return m_auteurs L'auteur de l'objet Reference
 */
const std::string&
Ouvrage::reqEditeur () const
{
  return m_editeur;
}


/**
 * \brief Accesseur pour l'attribut m_editeur
 * \return m_auteurs L'auteur de l'objet Reference
 */
const std::string&
Ouvrage::reqVille () const
{
  return m_ville;
}


/**
 * \brief Retourne une chaine de caractere qui contient l'information de l'objet Ouvrage
 * \return un string qui contient l'information formatee sur l'objet Ouvrage courant.
 */
std::string
Ouvrage::reqReferenceFormate () const
{
  std::ostringstream os;
  os << Reference::reqReferenceFormate ();
  os << reqVille () << " : ";
  os << reqEditeur () << ", ";
  os << Reference::reqAnnee () << ". ";
  os << Reference::reqIdentifiant () << ".";
  return os.str ();
}


/*
 * \brief Méthode permettant de faire une copie allouée sur le monceau de l'objet courant.
 */
Reference*
Ouvrage::clone () const
{
  return new Ouvrage (*this); // Appel du constructeur copie
}


/*
 * \brief Vérifier les invariants de la classe Ouvrage.
 *        m_editeur doit être toujours valide.
 *        m_ville doit toujours être supérieur à 0.
 */
void
Ouvrage::verifieInvariant () const
{
  INVARIANT (validerFormatNom (m_editeur) && !m_editeur.empty ());
  INVARIANT (validerFormatNom (m_ville) && !m_ville.empty ());
}

