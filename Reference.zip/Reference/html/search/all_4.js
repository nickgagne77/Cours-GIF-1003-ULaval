var searchData=
[
  ['operator_3d_3d_4',['operator==',['../classbiblio_1_1_reference.html#a376896263d84704f450119184761e39d',1,'biblio::Reference']]]
];
