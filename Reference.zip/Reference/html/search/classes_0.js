var searchData=
[
  ['reference_13',['Reference',['../classbiblio_1_1_reference.html',1,'biblio']]]
];
