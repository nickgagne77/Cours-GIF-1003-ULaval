var searchData=
[
  ['asgannee_17',['asgAnnee',['../classbiblio_1_1_reference.html#a9859c4b21b9696ddef0912dfd20b5707',1,'biblio::Reference']]]
];
